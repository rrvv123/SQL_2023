package test.book1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class test2 {
    // 연결 정보 (URL, 사용자, 암호)
    String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    String USER = "c##madang";
    String PWD = "madang";
    static Scanner scan = new Scanner(System.in);

    Connection con;

    public test2() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("드라이버 로드 성공");
            con = DriverManager.getConnection(URL, USER, PWD);
            System.out.println("데이터베이스 연결 성공");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void runSQL(int choice) {
        if (choice == 1) {
            System.out.println("검색할 도서명을 입력하세요: ");
            String input = scan.nextLine();

            String sql = "SELECT name, bookname, saleprice FROM customer, orders WHERE bookname LIKE '%" + input + "%' ORDER BY name";

            System.out.println("\t고객명\t도서명\t판매 가격");
            try {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    System.out.print("\t" + rs.getString("name"));
                    System.out.print("\t" + rs.getString("bookname"));
                    System.out.println("\t" + rs.getInt("saleprice"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("검색할 고객명을 입력하세요: ");
            String input = scan.nextLine();

            String sql = "SELECT name, bookname, saleprice FROM customer, orders WHERE name LIKE '%" + input + "%' ORDER BY name";

            System.out.println("\t고객명\t도서명\t판매 가격");
            try {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    System.out.print("\t" + rs.getString("name"));
                    System.out.print("\t" + rs.getString("bookname"));
                    System.out.println("\t" + rs.getInt("saleprice"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        test2 bList = new test2();

        System.out.println("검색 메뉴");
        System.out.println("1. 도서명으로 검색");
        System.out.println("2. 고객명으로 검색");
        System.out.print("옵션을 선택하세요: ");
        int choice = scan.nextInt();

        scan.nextLine(); // 개행 문자 처리

        bList.runSQL(choice);
    }
}