package test.book1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q5 {
    // 연결 정보 (URL, 사용자, 암호)
    String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    String USER = "c##madang";
    String PWD = "madang";
    static Scanner scan = new Scanner(System.in);

    Connection con;

    public Q5() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("드라이버 로드 성공");
            con = DriverManager.getConnection(URL, USER, PWD);
            System.out.println("데이터베이스 연결 성공");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
		
    // main메소드에서 runSQL(1)호출, 1은 검색메뉴 값을 의미
    // searchMenu가 1이면 도서명검색, 2이면 고객명 검색
 	public void runSQL(int searchMenu1, String searchWord1) {
 		String sql = "";
 	
 		switch (searchMenu1) {
 		case 1:
 			sql = "select name, b.bookname, saleprice from book b, customer c, orders o " //아래행과 연결을 할 때에는 꼭 마지막에 공백을 넣고  
 								+ "where c.custid = o.custid and b.bookid = o.bookid "    //다음행을 써야됨.
 								+ "and b.bookname like '%" + searchWord1 + "%' order by name";



 			break;
 		
 		case 2:
 			sql = "select name, b.bookname, saleprice from book b, customer c, orders o" 
 								+ "where c.custid = o.custid and b.bookid = o.bookid"
 								+ "and c.name like '%" + searchWord1 + "%' order by name";
 			break;
 		}
 		try {
 	 		// Connection 객체를 사용해서 문장객체를 생성 및 반환
 	 		Statement stmt = con.createStatement();
 	 		
 	 		// Statement 객체를 사용해서 SQL문을 실행한 후 ResultSet 집합 객체 반환 
 	 		ResultSet rs = stmt.executeQuery(sql);
 	 		
 	 		// 반복문을 사용해서 ResultSet 객체의 행개수 만큼 데이터를 가져와서 콘솔에 출력
 	 		// next()메소드는 데이터행을 접근할 수 있는 커서를 다음 행으로 이동시키는 기능을 함.
 	 		// 실제 cursor가 가리키는 데이터행이 존재하면 true를 반환, 데이터행이 존재하지 않으면 false를 반환.
 	 		System.out.printf("%-10s", "고객명");
	 		System.out.printf("%-20s", "도서명");
	 		System.out.printf("\t%7d\n", "판매가격");
	 		System.out.println("===================================================");
 	 		
 	 		while(rs.next()) {
 	 			System.out.printf("%-10s" + rs.getString("name")); // \t 탭키로 영문 8글자 정도 띄어쓰기해줌
 	 			System.out.printf("%-20s" + rs.getString("bookname"));
 	 			System.out.printf("\t%7d\n", rs.getInt("saleprice"));
 	 		}
 		}
 	 	catch (SQLException e) {
 	 		// TODO Auto-generated catch block
 			e.printStackTrace();
 	 	}
 		
 	}

    public static void main(int seatrchMenu1, String searchWord1) {
    	Q5 bList = new Q5();
 
 	    Scanner s1 = new Scanner(System.in);
 	    Scanner s2 = new Scanner(System.in);
 	    while(true) {
 	    	System.out.println("[검색 메뉴]");
 	    	System.out.println("1. 도서명으로 검색");
 	    	System.out.println("2. 고객명으로 검색");
 			System.out.println("3. 종료");
 			System.out.println("검색메뉴를 선택하세요.(1 또는 2를 입력): ");
 			int searchMenu = s1.nextInt();
 				String searchMenu1 = "";
 		
 			switch (searchMenu1) {
 				case 1:
 					System.out.println("도서명의 검색어를 입력:");
 					break;
 			
				case 2:
 					System.out.println("고객명의 검색어를 입력:");
 					break;
 			
 				case 3:
 					System.out.println("프로그램을 종료합니다.");
 					try {
 						bList.con.close();
 						s1.close();
 						s2.close();
 					}
 					catch (SQLException e) {
 						e.printStackTrace();
 					}
 					return;
 				} 	
 	   }
 	   searchWord1 = s2.nextLine();
 	 	
 	   bList.runSQL(seatrchMenu1, searchWord1);
     }
}