package test.book1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q2 {
	// 연결하기 위해 필요한 정보(url, user, pwd)
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	Scanner scan = new Scanner(System.in);
	
	Connection con;
	
	public Q2() {		
		// JDBC Driver Memory에 Load한다.
		// TODO Auto-generated constructor stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 모드 성공");
		// connection 객체 생성
			con = DriverManager.getConnection(URL, USER, PWD);
			System.out.println("DB 연결 성공");
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void runSQL() {
		System.out.println("찾을 책 이름 입력해주세요: ");
		String input = scan.nextLine();
		
		String sql = "select bookid, bookname, price from book where bookname like '%" +input + "%' order by bookid";
		
		System.out.println("\t도서번호\t도서명\t가격");
		try {
			// Connection 객체를 사용해서 문장객체를 생성 및 반환
			Statement stmt = con.createStatement();
			
			// Statement 객체를 사용해서 SQL문을 실행한 후 ResultSet 집합 객체 반환 
			ResultSet rs = stmt.executeQuery(sql);
			
			// 반복문을 사용해서 ResultSet 객체의 행개수 만큼 데이터를 가져와서 콘솔에 출력
			// next()메소드는 데이터행을 접근할 수 있는 커서를 다음 행으로 이동시키는 기능을 함.
			// 실제 cursor가 가리키는 데이터행이 존재하면 true를 반환, 데이터행이 존재하지 않으면 false를 반환.
			while(rs.next()) {
				System.out.print("\t" + rs.getInt("bookid")); // \t 탭키로 영문 8글자 정도 띄어쓰기해줌
				System.out.print("\t" + rs.getString("bookname"));
				System.out.println("\t" + rs.getInt("price"));
			}
			
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		Q2 bList = new Q2();
		bList.runSQL();
	}
}